# Several worker calls: calls

Instead of one `worker` + `request`, a tool can declare `calls`: named Prometheus queries executed
**one after another**, possibly on different instances. Their results form an object `{name: result}`
that goes into `process` and `response` like an ordinary worker answer.

## When to use it

- Values for the second query are only known after the first: the top-N pods, an instance list.
- The answer needs an instant and a range query together (the top-N now, then their history).
- Data from different Prometheus instances (`prom_prod` and `prom_staging`).
- Several range queries that `join` stitches into one multivariate series (anomaly_mv, ensemble,
  ssa_mv): one call per signal.

When not to: if one query can return everything (one instance, no `join`), `label_replace` + `or` is
cheaper ([prometheus.md](prometheus.md#several-metrics-in-one-query)). If a second call is needed *for each
element* of the first (a separate query per pod), that is a scenario, not a tool: give the agent two
tools. There are no loops, parallel calls or conditional skipping.

## Syntax

```yaml
calls:
  - name: top                       # result key; ^[A-Za-z_][A-Za-z0-9_]*$, unique
    worker: prometheus              # an instance from the config
    request:                        # as for a single-call tool
      type: instant
      query: |
        topk({{ .top }}, sum by (pod) (container_memory_working_set_bytes{namespace={{ promLabel .namespace }}, container!=""}))
    jq: '[.result[] | {pod: .metric.pod, bytes: (.value[1] | tonumber? // null)}]'   # optional; its output is stored
  - name: history
    worker: prometheus
    request:
      type: range
      query: |
        … pod=~{{ … result "top" … }} …
      start: "now-{{ promDuration .range }}"
      end: now
      step: "{{ .step }}"
```

| Field | Required | Purpose |
|---|---|---|
| `name` | yes | the key in `process`/`response` input and in `result "name"` |
| `worker` | yes | instance; calls may use different instances |
| `request` | yes | the same keys and checks as a single-call `request` |
| `jq` | no | gojq over **this** call's answer; `$params` available; its output is stored instead of the raw answer |

Rules:

- `calls` and top-level `worker`/`request` are mutually exclusive.
- Calls run strictly in order; the first failure stops the tool and later calls don't run.
- Total time is the sum of the calls; each instance has its own timeout.
- Every referenced instance must be configured.

## How templates see earlier results

`result "name"` returns a stored result (after its `jq`). In `request` the root `.` stays the params.

| Where | `result` sees |
|---|---|
| `calls[i].request` | calls **before** i |
| `process[j].with` | all calls |
| `response.render` | all calls |
| `response.jq`, `calls[i].jq` | no `result`: `response.jq` already gets `{top: …, history: …}`, a per-call jq sees only its own answer |

A literal reference to a call that does not exist or has not run yet is a **startup** error:
`calls[0].request: result "history": no call result is available here`. A dynamic name (`result .x`) is
checked at call time.

## The first call returns a flat shape

text/template is bad at digging in a raw Prometheus answer (`.result[].metric`, string values).
Rule: **the first call's `jq` returns a flat shape** (a list of names or of flat objects) and the second
call's template only assembles a string from it. This shape also reaches `response.jq`, so keep
everything the final join needs (the current value `bytes`), not just the key.

The idiom "list of names → regex for PromQL":

```
{{- $names := list }}{{ range result "top" }}{{ $names = append $names (promRegex .pod) }}{{ end -}}
… pod=~{{ promLabel (join "|" $names | default "__none__") }} …
```

- `promRegex` escapes each name, `promLabel` quotes the whole regex for PromQL;
- `default "__none__"` protects against an empty list: `pod=~""` would match series **without** a
  `pod` label, `__none__` matches nothing;
- `{{-` and `-}}` keep the query from starting with an empty line.

With hundreds of names the regex gets long (Prometheus copes, the query goes by POST), but narrow the
first call (`topk` with a `top` parameter, a label filter).

## Joining results in response.jq

```jq
(.history.result | map({key: .metric.pod, value: ([.values[][1] | tonumber?] | max)}) | from_entries) as $peak
| [.top[] | . + {peak_bytes: $peak[.pod]}]
| sort_by(-(.bytes // -1))
```

`$peak[.pod]` is `null` for a pod without samples in the window: it stays in the list and `render`
prints `n/a`. Lead with the call that defines which rows exist (here `top`: the pods with the most
memory now).

Without `response`, the agent gets the whole `{top: …, history: …}` object: fine for debugging, too
much for work.

## description

Say what **each** call adds and what it needs ("Finds the `top` pods by current memory working set
(cAdvisor), then their peak over `range`…"; with two instances, name both). If an instance or an
exporter is missing in an environment, the agent must understand why the tool fails or returns nothing
and what to use instead.

## Errors

At startup:

| Message | Cause |
|---|---|
| `calls must be a list of calls ({name: …, worker: …, request: {...}, jq: …})` | `calls` written as a map |
| `calls[0].name: required (it is the key the result is stored under)` | no name |
| `calls[1].name: duplicate call name "top" (also calls[0])` | duplicate name |
| `calls[1].worker: unknown worker "prom_staging" (configured: prometheus)` | no such instance |
| `calls[1] (history): request.time: only valid for type: instant` | a worker error in that call |
| `calls[0].jq: jq parse: …` | per-call jq syntax |
| `calls[0].request: result "history": no call result is available here` | reference to a later call |
| `worker: not allowed together with calls (set calls[i].worker instead)` | both forms at once |

At call time the stages are the usual ones (`request`, `worker`, `jq`) and the text names the call:
`tool pod_memory_peak failed at stage worker: calls[1] (history): prometheus bad_data error: …`.
`-validate` shows the chain as `calls=top>history`.

Test: the first call returns an empty list (the second request must not become "everything"), the
first call fails (the agent sees `calls[0] (…)`), the total time of both calls.
