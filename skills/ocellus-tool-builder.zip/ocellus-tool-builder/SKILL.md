---
name: ocellus-tool-builder
description: Designs and writes a ready-to-use tool YAML file for the Ocellus AI MCP server (ocellusai-mcp) from a user's need. Interviews the user about the question the tool must answer, the Prometheus metrics and PromQL behind it, parameters, analysis (thresholds, anomalies, outliers, forecasts) and the answer the agent should get, then writes tools/<name>.yaml, validates it with `ocellusai-mcp -validate` and test-calls it. Use when the user wants a new ocellusai-mcp tool, wants to adapt or fix an existing one, or asks how to expose a Prometheus metric or PromQL query to AI agents through ocellusai-mcp. Always talk to the user in the language they write in.
---

# Ocellus AI tool builder

You turn a user's need ("I want the agent to tell me which pods eat unusually much memory") into one
working YAML file in the ocellusai-mcp tool catalog. A tool is data, not code: one file says where the data
comes from, how it is analysed and what the calling AI agent reads back.

## Language

**Talk to the user in the language of their messages.** This skill is written in English, but every
question, option, design summary, explanation and final report goes to the user in their language; if
they switch languages, switch with them. Translate the questions from [reference/interview.md](reference/interview.md),
don't paste them in English.

The tool file itself is read by AI agents, so write its `description`, parameter descriptions and
`render` text in **English** (the catalog convention) unless the user explicitly asks for another
language. Never translate YAML keys, field names, function names or identifiers.

## How a tool works

```
agent's JSON arguments
  → params    JSON Schema check, defaults filled in
  → request   Go text/template over the params → a request for the worker   ┐ once (worker + request)
  → worker    prometheus (PromQL: instant or range query)                   │ or per call of `calls`,
  → jq        optional per-call jq (calls only)                             ┘ results → {name: JSON}
  → process   optional chain: jq, anomaly, outliers, join, anomaly_mv,
              anomaly_ensemble, cluster_events, ssa, ssa_mv
  → jq        optional final reshaping (gojq, $params available)
  → render    optional text for the agent (Go text/template)
```

The agent sees `name`, `description` and the JSON Schema built from `params` in `tools/list`; a call
returns the rendered text (or pretty JSON) plus `structuredContent` (the jq result). The server reads the
catalog once at startup and **one broken file stops the whole server**, so every file you write must
pass validation.

## Workflow

Copy this checklist and keep it updated while you work:

```
Tool build progress:
- [ ] 1. Orient: config, worker instances, tools_dir, binary, existing tools
- [ ] 2. Interview: the need, source, scope, analysis, output, parameters
- [ ] 3. Design: pick the pattern, write the spec, user confirms it
- [ ] 4. Write: tools_dir/<name>.yaml from the closest template
- [ ] 5. Validate: ocellusai-mcp -validate passes
- [ ] 6. Test call (with the user's permission): defaults, empty result, bad arguments
- [ ] 7. Deliver: file, what the agent sees, sample output, how to deploy
```

### 1. Orient (find out, don't ask)

Before asking anything, learn what you can from the environment:

- **Config**: usually `config.yaml` in the server's working directory (`config.example.yaml` in a source
  checkout). Read `tools_dir` and `workers`. Each entry under `workers` is a Prometheus *instance*;
  its `type` (`prometheus`) defaults to the entry name. Note the instance names (tools reference them
  as `worker: <name>`) and each instance's `url`. Never repeat secrets (headers, tokens, `${VAR}`
  values) back to the user.
- **Binary**: `./bin/ocellusai-mcp` or `ocellusai-mcp` on `PATH`; in a source checkout `make build` builds it.
- **Existing tools** in `tools_dir`: avoid duplicate names and duplicate tools (offer to extend an
  existing one instead), and copy local conventions: the `job` label in selectors, the `at` parameter,
  the style of `render` text.
- **Metric and label names**: guessing is the most common cause of a tool that loads but returns
  nothing. With the user's permission, run read-only queries against their Prometheus to confirm names
  and labels ([reference/prometheus.md](reference/prometheus.md#discovering-metrics-and-labels)).

If there is no ocellusai-mcp setup at hand (the user only wants the file), ask for the worker instance
name or assume `prometheus`, say so, and give them the validation command.

### 2. Interview

Follow [reference/interview.md](reference/interview.md). The essentials:

- Start from the **question the tool must answer**, in the user's words, with an example.
- Ask in **rounds of at most 3–4 questions**. Give options and mark a recommended default, so "you
  decide" is always a valid answer. If a structured question tool (such as AskUserQuestion) is
  available, use it for multiple-choice questions.
- Don't ask what you can look up (step 1) or what has a safe default; list the defaults in the spec.
- **Always** settle these before writing: data source and worker instance, object and how it is
  identified (labels), time scope, analysis, the answer's content, and, for any detector, the
  smallest change worth reporting in real units (`min_delta`).

### 3. Design

Pick the pattern and the closest template:

| The need | Pattern | Start from |
|---|---|---|
| Current value / top-N of a metric | prometheus `instant` → jq → render | [templates/prometheus-snapshot.yaml](templates/prometheus-snapshot.yaml) |
| Several metrics of one object in one answer, peak or time above a threshold over a window | one `instant` query with `label_replace` + `or`, subqueries | [reference/prometheus.md](reference/prometheus.md#recipes) |
| "Anything unusual in each object's own history?" | `range` → `anomaly` (zscore / iqr) | [templates/prometheus-anomaly.yaml](templates/prometheus-anomaly.yaml) |
| "Which object stands out among its peers right now?" | `instant` → jq → `outliers` | [templates/prometheus-outliers.yaml](templates/prometheus-outliers.yaml) |
| Anomalous time segments, which metric is to blame, several signals per object | `calls` (one `range` per signal) → `join` → `anomaly_ensemble` | [templates/multi-metric-ensemble.yaml](templates/multi-metric-ensemble.yaml) |
| The usual relation between two metrics broke | `calls` → `join` → `anomaly_mv` | [reference/processors.md](reference/processors.md#anomaly_mv) |
| The same incident on many hosts at once | … → `anomaly_ensemble` → jq → `cluster_events` | [reference/processors.md](reference/processors.md#cluster_events) |
| Trend, daily cycle, forecast, capacity | `range` → `ssa` (one metric) or `join` → `ssa_mv` | [templates/prometheus-forecast.yaml](templates/prometheus-forecast.yaml) |

Then write a short **spec** in the user's language (format in [reference/interview.md](reference/interview.md#the-spec))
and get a clear "yes" before writing the file. A one-line change to an existing tool needs no spec.

### 4. Write the file

Copy the closest template, adapt it, and follow the reference for each section:

| Section | Reference |
|---|---|
| File structure, `name`, `description`, `params`, templates and their functions | [reference/tool-format.md](reference/tool-format.md) |
| `worker: prometheus`, PromQL recipes, the `at` parameter | [reference/prometheus.md](reference/prometheus.md) |
| `calls` (several queries in sequence) | [reference/calls.md](reference/calls.md) |
| `process` and every processor | [reference/processors.md](reference/processors.md) |
| `response.jq` and `response.render` | [reference/response.md](reference/response.md) |

Every template here passes `-validate` and has been called against real data or mocks. More real
examples, if the ocellusai-mcp repository is at hand: `tools/` (working catalog: estate overview, VM
anomaly ensembles, SSA forecasts, PostgreSQL, Kafka) and `tools-test/` (small tools, one feature each;
copy only the Prometheus-based ones).

Save it as `<tools_dir>/<name>.yaml`, file name equal to `name`. Start the file with a short `#`
comment: what it does and what it assumes about the data (exporter, `job` label), so the next person
can adapt it.

### 5–7. Validate, test, deliver

Follow [reference/validate-and-deliver.md](reference/validate-and-deliver.md): `-validate` must pass;
a test call is the only way to catch wrong field names, PromQL errors and jq/render failures, so ask the
user for permission and run one. Finish with the file path, what the agent will see, a sample answer,
assumptions the user should check and how to deploy (the server reads the catalog only at startup).

## Rules that prevent most broken tools

- **Strict parsing.** Only documented fields exist; an unknown field anywhere (`title`, `annotations`,
  `items` in a param) stops the server.
- **Quote every YAML value that starts with `{{`**: `step: "{{ .step }}"`.
- **PromQL values go through helpers**: label values `{{ promLabel .x }}`, literals inside your own
  regex `promRegex`, durations `[{{ promDuration .window }}]`, numbers come from `integer`/`number`
  params.
- **Every parameter that reaches a query is constrained**: `pattern` anchored with `^…$`, `enum`,
  `minimum`/`maximum`.
- **Detectors** (`anomaly`, `outliers`, `anomaly_mv`, `anomaly_ensemble`) always get `min_delta`: the
  smallest meaningful change in the metric's units, exposed as a parameter in units the agent
  understands.
- **jq**: wrap results in `[...]` or `{...}`, keep every key present (null when unknown), use
  `tonumber? // null`, sort and cap lists, don't round.
- **render**: handle the empty result first, print nil as `n/a`, use `printf "%.2f" (float64 .x)`,
  name the window, threshold and units in the text.
- **description** says what is returned, from which source, in which units, what an empty answer
  means and when to use the tool. It is the only thing the agent reads before calling.
